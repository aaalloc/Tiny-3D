# tests

The tests are written with C++20 and [Catch2](https://github.com/catchorg/Catch2). To run, one also
needs to init the submodules and therefore download the [glTF-Sample-Models](https://github.com/KhronosGroup/glTF-Sample-Models/).
