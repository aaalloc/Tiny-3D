# gl_viewer

A fairly simple GL 4.6 glTF viewer made using fastgltf. 
